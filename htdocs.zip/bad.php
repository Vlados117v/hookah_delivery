<!DOCTYPE html>
<html lang="ru">
<head>
	<title>Доставка кальяна по городу Ижевск КРУГЛОСУТОЧНО "NoName"</title>
<meta charset="utf-8">	
<meta name="robots" content="noindex">
<link rel="stylesheet" type="text/css" href="/styles.css">


</head>



<body>
	<div class="main_content">

<div class="header">
	<img class="logo" src="/images/logo.gif" width="400" height="400" alt="Доставка кальяна Ижевск">
	<h1>Упс, что то пошло не так !!!<br>вы всегда можете позвонить нам или воспользоваться социальными сетями !<br>(вы будете перенаправлены на главную страницу)</h1>
</div>
</div>

<script>
	setTimeout(function(){
  window.location.href = '/index.php';
}, 8 * 1000);
</script>
	</body>



</html>